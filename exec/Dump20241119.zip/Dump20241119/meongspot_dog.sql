-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: k11d107.p.ssafy.io    Database: meongspot
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dog`
--

DROP TABLE IF EXISTS `dog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dog` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `age` int NOT NULL,
  `birth` date DEFAULT NULL,
  `breed` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` enum('FEMALE','MALE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `introduction` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_neuter` bit(1) NOT NULL,
  `name` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_image` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` enum('LARGE','MEDIUM','SMALL') COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` bigint DEFAULT NULL,
  `is_delete` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8u1ctkdq5c2sta6q85u8n8sw6` (`owner_id`),
  CONSTRAINT `FK8u1ctkdq5c2sta6q85u8n8sw6` FOREIGN KEY (`owner_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dog`
--

LOCK TABLES `dog` WRITE;
/*!40000 ALTER TABLE `dog` DISABLE KEYS */;
INSERT INTO `dog` VALUES (90,1,'2024-10-10','골든 리트리버','MALE','오이를 좋아하는 오이멍입니다.',_binary '','오이멍','https://meongspotd107.s3.ap-northeast-2.amazonaws.com/75747d78-2a37-471a-8840-bb1be97da0b1_%EC%98%A4%EC%9D%B4%EB%A9%8D.jpg','SMALL',39,_binary '\0'),(91,4,'2021-07-07','시바견','MALE','화성을 좋아해요',_binary '','까미','https://meongspotd107.s3.ap-northeast-2.amazonaws.com/bb4c63f9-0562-4db2-b795-a815ca621dd0_1000014296.jpg','MEDIUM',41,_binary '\0'),(92,6,'2019-07-30','차우차우','MALE','귀여운 감자랑 친구해요 !! ㅎㅎ',_binary '','감자','https://meongspotd107.s3.ap-northeast-2.amazonaws.com/bb1fb303-269a-4450-a9eb-6e8c7619d6db_%EA%B3%B0%EC%9E%901.png','LARGE',40,_binary '\0'),(93,3,'2022-04-07','골든 리트리버','MALE','사람이랑 강아지를 좋아하는 골디입니다 깨발랄한 성격이에요',_binary '','골디','https://meongspotd107.s3.ap-northeast-2.amazonaws.com/73dbd049-39be-4d34-9e4f-233f8cddd62d_956b8e6123be5.png','LARGE',42,_binary '\0'),(94,3,'2022-10-10','시베리안 허스키','FEMALE','시베리안허스키 근이에요',_binary '','근이','https://meongspotd107.s3.ap-northeast-2.amazonaws.com/fc78886d-bf9a-4b44-8509-356f7492dd72_1000015563.jpg','LARGE',44,_binary '\0'),(95,5,'2020-01-06','골든 리트리버','MALE','귀엽고 활반한 웰시코기에요',_binary '\0','몽땅이','https://meongspotd107.s3.ap-northeast-2.amazonaws.com/b558a164-445f-4e89-b4ce-d5b7009aea1a_%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%281%29.jfif','LARGE',43,_binary '\0'),(96,2,'2023-10-15','포메라니안','FEMALE','사람은 좋아하는데 같은 강아지들한테는 조금 소심해요 낯은 가리지만 친해지면 잘 놀아요 ~~',_binary '','탄이','https://meongspotd107.s3.ap-northeast-2.amazonaws.com/f8b5813a-0fef-4a26-806b-8ed6259729da_2022020218064957624_l.jpg','SMALL',42,_binary '\0'),(97,3,'2022-07-04','시바견','FEMALE','크지만 착한 친구입니다',_binary '','모지','https://meongspotd107.s3.ap-northeast-2.amazonaws.com/5dfacddc-8548-4686-9cae-b735b5aa4dc3_1000014293.webp','LARGE',41,_binary '\0'),(98,5,'2020-07-09','비숑 프리제','FEMALE','사람은 좋아하는데 같은 강아지는 낯가려요ㅠㅠ\r\n친하게 지내요~?',_binary '','삐삐','https://meongspotd107.s3.ap-northeast-2.amazonaws.com/7eb2f037-a7d8-4e8e-8606-d10296d77b5b_20210814_145924.jpg','SMALL',44,_binary '\0'),(99,4,'2021-05-09','포메라니안','FEMALE','순딩이 뽀미에요~ 다른 강아지 친구와 잘놀아요~',_binary '','뽀미','https://meongspotd107.s3.ap-northeast-2.amazonaws.com/d5728977-ac21-4523-971c-a6fc7c8aea63_1703946776119.jpg','SMALL',44,_binary '\0'),(100,2,'2023-07-09','닥스훈트','FEMALE','활발한 이끼에요~~ 푸들을 무서워해요~~',_binary '','이끼','https://meongspotd107.s3.ap-northeast-2.amazonaws.com/be353110-bd35-4d88-a7e7-34b8e53f4f87_20231227_012114.jpg','MEDIUM',40,_binary '\0');
/*!40000 ALTER TABLE `dog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-19 13:43:20
