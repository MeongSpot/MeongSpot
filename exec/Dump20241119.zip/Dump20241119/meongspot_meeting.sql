-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: k11d107.p.ssafy.io    Database: meongspot
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `meeting`
--

DROP TABLE IF EXISTS `meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `detail_location` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_done` bit(1) NOT NULL,
  `max_participants` int NOT NULL,
  `meeting_at` datetime(6) NOT NULL,
  `title` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat_room_id` bigint DEFAULT NULL,
  `spot_id` bigint DEFAULT NULL,
  `information` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `participants` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9unwua10bgxmxqu1qydn6d8fl` (`chat_room_id`),
  KEY `FK1c4pxvl7sciaqj0e1k19bb48b` (`spot_id`),
  CONSTRAINT `FK1c4pxvl7sciaqj0e1k19bb48b` FOREIGN KEY (`spot_id`) REFERENCES `meeting_spot` (`id`),
  CONSTRAINT `FK9unwua10bgxmxqu1qydn6d8fl` FOREIGN KEY (`chat_room_id`) REFERENCES `chat_room` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting`
--

LOCK TABLES `meeting` WRITE;
/*!40000 ALTER TABLE `meeting` DISABLE KEYS */;
INSERT INTO `meeting` VALUES (102,'2024-11-18 14:38:34.821556','한누리 공원 공중 화장실 앞',_binary '\0',4,'2024-11-21 19:00:00.000000','한누리 공원 11일 오후 7시 산책해요',143,14450,'소형견이면 좋겠어요. 저희 강아지가 태어난지 1개월밖에 안돼서 큰 강아지를 무서워해요',2),(103,'2024-11-18 14:43:28.669170','찰밭공원 정자 앞!',_binary '\0',4,'2024-11-21 14:00:00.000000','편하게 산책하실분',145,14421,'서로 편하게 이야기하면서 산책해요~',1),(104,'2024-11-18 14:44:52.928238','근처 주차장',_binary '\0',4,'2024-11-19 18:00:00.000000','산책하실분 ~~~',146,14450,NULL,1),(105,'2024-11-18 14:45:45.470873','건강공원 입구',_binary '\0',6,'2024-11-23 15:00:00.000000','건강공원에서 건강하게 산책해요',147,14498,'건강한 산책 하고싶어요',1),(106,'2024-11-18 14:46:42.851904','과학관 옆',_binary '\0',3,'2024-11-22 14:00:00.000000','같이 소풍가실분 ?!',148,14419,'같이 점심 먹고 산책 하실분 ?! 도시락 먹어요 ㅎㅎ',3),(107,'2024-11-18 14:49:40.313077','바로 옆 편의점 앞',_binary '\0',5,'2024-11-23 13:00:00.000000','저희 감자랑 친구해요!',149,14450,'주말 낮에 만나실분 있을까요?\n저희 감자랑 같이 오래 산책해요! ~~~',2),(108,'2024-11-18 15:00:29.049166','인의공원 가로등 앞',_binary '\0',5,'2024-11-25 20:15:00.000000','오이멍이랑 모임하실분?',151,14502,'오이멍은 오이를 좋아해요',2),(110,'2024-11-18 17:36:10.060819','시계탑 밑',_binary '\0',6,'2024-11-28 22:57:00.000000','저녁 산책 하실분',153,14450,'같이 재밌게 산책해요',1),(111,'2024-11-18 17:49:25.280592','제 1 주차장',_binary '\0',5,'2024-11-22 20:00:00.000000','동락공원 한바퀴 돌아요',154,14419,'금욜 저녁에 동락공원 산책 하실분 !!!',1),(112,'2024-11-18 17:49:56.526935','동락공원 과학관 앞!',_binary '\0',6,'2024-11-21 14:00:00.000000','반려견 친구 만드실분~',155,14419,'편하게 같이 산책해요',1),(113,'2024-11-18 17:50:00.560570','동락공원 제2주차창 앞',_binary '\0',6,'2024-11-22 19:00:00.000000','오이멍과 동락공원에서 산책해요',156,14419,'오이멍은 오이를 좋아해요',1),(114,'2024-11-18 17:53:59.537857','구미 과학관 앞에서 만나요',_binary '\0',4,'2024-11-24 22:00:00.000000','같이 산책해요~~',157,14419,'저녁 산책 하실분?',1),(117,'2024-11-19 09:09:30.833832','동락공원 과학관 옆',_binary '\0',6,'2024-11-19 19:00:00.000000','대형견 모여라~!',161,14419,'대형견 환영!! 매너있는 사람 같이 산책해요!',5),(118,'2024-11-19 13:06:28.776874','미쓰럼틀앞',_binary '\0',5,'2024-11-20 18:00:00.000000','진평동 겅어지 모여라',163,14450,'같이 즐겁게 산책해요~~ ',1);
/*!40000 ALTER TABLE `meeting` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-19 13:43:22
