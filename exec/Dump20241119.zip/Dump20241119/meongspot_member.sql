-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: k11d107.p.ssafy.io    Database: meongspot
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `birth` date NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `gender` enum('FEMALE','MALE') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_withdraw` bit(1) NOT NULL,
  `login_id` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nickname` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('ROLE_ADMIN','ROLE_OWNER','ROLE_USER') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `withdrawn_at` datetime(6) DEFAULT NULL,
  `profile_image` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKenfm5patwjqulw8k4wwuo6f60` (`login_id`),
  UNIQUE KEY `UKhh9kg6jti4n1eoiertn2k6qsc` (`nickname`),
  UNIQUE KEY `UK6ithqvsvrcawbi9dtxu0ttsny` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'1999-06-19','2024-11-10 09:22:52.178891','MALE',_binary '\0','admin107','관리자','관리자','$2a$10$FHv8QEx16dvonFI1c7f/CO1XiZ827D023cbO90zNxZCUk6y5xVtBO','01000000000','ROLE_ADMIN',NULL,NULL),(39,'1999-06-19','2024-11-18 14:32:28.489479','MALE',_binary '\0','zx8571','원승현','오이멍아빠','$2a$10$M4DLLxyp1nrpc1tpoyUJNO51ukFRKVsNndbL/jp2NrUQbuUlsZhKa','01085914442','ROLE_OWNER',NULL,'https://meongspotd107.s3.ap-northeast-2.amazonaws.com/0e9f1f2a-1de9-45fd-8e8c-ab0a4dad470c_%EA%B0%95%EB%8F%99%EC%9B%90.jpg'),(40,'2000-04-04','2024-11-18 14:33:58.113844','FEMALE',_binary '\0','kitty123','박은지','감자누나','$2a$10$.pgOY0VkcLThJiJNAsIo7uk/al0RUUoSvqOV4ZZtPyHU7DzdLxH8m','01025784357','ROLE_OWNER',NULL,'https://meongspotd107.s3.ap-northeast-2.amazonaws.com/79124c67-d732-451f-b7b3-5ebc6e487ff8_%EA%B0%90%EC%9E%90.png'),(41,'1999-08-01','2024-11-18 14:38:19.817108','MALE',_binary '\0','suwhan2','최수환','미지아빠','$2a$10$YhKBS18OmtWtgAXHJuQtTOHK/jGKqusTI7cRNfa5SQGNIeC0z8EKe','01049137069','ROLE_OWNER',NULL,'https://meongspotd107.s3.ap-northeast-2.amazonaws.com/287457c9-8ed2-4a5e-a061-87ff72906446_1000013524.webp'),(42,'1997-07-26','2024-11-18 14:53:45.468604','FEMALE',_binary '\0','yejin','박예진','초코쿠키','$2a$10$K3gtqQ8NnldVOFC66DSFGe/SmsjwtYAyEUXVra5jAKHzjCgLz5YX2','01054740072','ROLE_OWNER',NULL,'https://meongspotd107.s3.ap-northeast-2.amazonaws.com/6bfe417b-7d5c-45dd-8ff5-1a09d638c31c_a2f8722c778a5a816a7bf3f5dac4f100.jpg'),(43,'1999-01-23','2024-11-18 14:55:18.340005','MALE',_binary '\0','woong','송근웅','woong','$2a$10$eCTwRrCoKztml/Pg7b9g8.BI2OkLretqXEpCRpAptDfQYWxuXbznW','01066624597','ROLE_OWNER',NULL,'https://meongspotd107.s3.ap-northeast-2.amazonaws.com/1fd527f9-b50b-455e-b351-a35b2492c0a4_%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%20%282%29.jfif'),(44,'1998-10-11','2024-11-18 14:57:28.343963','FEMALE',_binary '\0','asdf','박주영','낑깡','$2a$10$fAre.Bsi4f159v9ApI36q.UXU.BF1fmersKJP3tshS3TViPMNJ2fu','01075467182','ROLE_OWNER',NULL,'https://meongspotd107.s3.ap-northeast-2.amazonaws.com/1e3d8e1b-5dad-41e5-980f-04d62b128a63_1000013657.jpg');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-19 13:43:21
