-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: k11d107.p.ssafy.io    Database: meongspot
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `chat_room_id` bigint DEFAULT NULL,
  `content` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `friend_id` bigint DEFAULT NULL,
  `is_deleted` bit(1) NOT NULL,
  `is_read` bit(1) NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiver_id` bigint NOT NULL,
  `sender_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1jpw68rbaxvu8u5l1dniain1l` (`receiver_id`),
  KEY `FKovuqht5f5v592yehlp3tgji9y` (`sender_id`),
  CONSTRAINT `FK1jpw68rbaxvu8u5l1dniain1l` FOREIGN KEY (`receiver_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FKovuqht5f5v592yehlp3tgji9y` FOREIGN KEY (`sender_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=324 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (231,NULL,'오이멍아빠이 친구요청을 하였습니다.','2024-11-18 14:39:31.800036',39,_binary '',_binary '\0','FRIEND_INVITE',41,39),(232,NULL,'오이멍아빠이 친구요청을 하였습니다.','2024-11-18 14:39:32.318933',39,_binary '',_binary '\0','FRIEND_INVITE',41,39),(233,NULL,'지지아빠이 친구요청을 수락하였습니다.','2024-11-18 14:39:36.261638',NULL,_binary '',_binary '','FRIEND_ACCEPT',39,41),(234,NULL,'감자누나이 모임에 참가하셨습니다.','2024-11-18 14:40:15.963499',NULL,_binary '',_binary '','MEETING_JOIN',39,40),(235,NULL,'감자누나이 모임에 참가하셨습니다.','2024-11-18 14:46:56.476419',NULL,_binary '',_binary '','MEETING_JOIN',39,40),(236,NULL,'오이멍아빠이 친구요청을 하였습니다.','2024-11-18 14:55:14.143259',39,_binary '',_binary '','FRIEND_INVITE',40,39),(237,NULL,'감자누나이 친구요청을 수락하였습니다.','2024-11-18 14:56:54.195435',NULL,_binary '',_binary '','FRIEND_ACCEPT',39,40),(238,NULL,'감자누나이 모임에 참가하셨습니다.','2024-11-18 14:57:23.443119',NULL,_binary '',_binary '','MEETING_JOIN',39,40),(239,NULL,'초코쿠키이 모임에 참가하셨습니다.','2024-11-18 14:57:35.930977',NULL,_binary '\0',_binary '','MEETING_JOIN',40,42),(240,NULL,'감자누나이 모임에 참가하셨습니다.','2024-11-18 15:00:48.862665',NULL,_binary '\0',_binary '','MEETING_JOIN',39,40),(241,NULL,'감자누나이 모임에 참가하셨습니다.','2024-11-18 15:01:46.686470',NULL,_binary '\0',_binary '','MEETING_JOIN',39,40),(242,NULL,'초코쿠키이 친구요청을 하였습니다.','2024-11-18 15:04:24.427078',42,_binary '',_binary '\0','FRIEND_INVITE',44,42),(243,NULL,'낑깡이 친구요청을 수락하였습니다.','2024-11-18 15:04:32.432110',NULL,_binary '',_binary '\0','FRIEND_ACCEPT',42,44),(244,NULL,'낑깡이 모임에 참가하셨습니다.','2024-11-18 15:15:16.820680',NULL,_binary '\0',_binary '','MEETING_JOIN',40,44),(245,NULL,'낑깡이 모임에 참가하셨습니다.','2024-11-18 15:15:17.067392',NULL,_binary '\0',_binary '','MEETING_JOIN',42,44),(246,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 15:21:02.133319',NULL,_binary '',_binary '','WALKING',44,42),(247,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 15:22:53.030410',NULL,_binary '',_binary '','WALKING',44,42),(248,NULL,'오이멍아빠이 산책을 시작하셨습니다.','2024-11-18 15:31:17.549812',NULL,_binary '\0',_binary '','WALKING',40,39),(249,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 15:32:54.470085',NULL,_binary '',_binary '','WALKING',44,42),(250,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 15:34:37.803289',NULL,_binary '',_binary '','WALKING',44,42),(251,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 15:54:49.854795',NULL,_binary '',_binary '','WALKING',44,42),(252,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 15:55:01.909830',NULL,_binary '',_binary '','WALKING',44,42),(253,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:02:43.109749',NULL,_binary '',_binary '','WALKING',44,42),(254,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:09:58.796351',NULL,_binary '',_binary '','WALKING',44,42),(255,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:10:04.447542',NULL,_binary '',_binary '','WALKING',44,42),(256,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:14:28.526708',NULL,_binary '',_binary '','WALKING',44,42),(257,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:14:29.683684',NULL,_binary '',_binary '','WALKING',44,42),(258,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:14:30.701516',NULL,_binary '',_binary '','WALKING',44,42),(259,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:14:31.684674',NULL,_binary '',_binary '','WALKING',44,42),(260,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:14:32.631100',NULL,_binary '',_binary '','WALKING',44,42),(261,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:23:12.116128',NULL,_binary '',_binary '','WALKING',44,42),(262,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:24:26.124292',NULL,_binary '',_binary '','WALKING',44,42),(263,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:24:45.963186',NULL,_binary '',_binary '','WALKING',44,42),(264,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:30:08.222923',NULL,_binary '',_binary '','WALKING',44,42),(265,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-18 16:53:36.402207',NULL,_binary '',_binary '','WALKING',44,42),(266,NULL,'지지아빠이 산책을 시작하셨습니다.','2024-11-18 17:33:29.087794',NULL,_binary '\0',_binary '','WALKING',39,41),(267,NULL,'woong이 모임에 참가하셨습니다.','2024-11-18 17:37:03.538497',NULL,_binary '\0',_binary '','MEETING_JOIN',40,43),(268,NULL,'초코쿠키이 모임에 참가하셨습니다.','2024-11-18 17:37:16.486741',NULL,_binary '\0',_binary '','MEETING_JOIN',40,42),(270,NULL,'초코쿠키이 모임에 참가하셨습니다.','2024-11-18 17:37:16.721420',NULL,_binary '\0',_binary '','MEETING_JOIN',43,42),(272,NULL,'초코쿠키이 친구요청을 하였습니다.','2024-11-18 17:38:54.870990',42,_binary '',_binary '\0','FRIEND_INVITE',43,42),(273,NULL,'woong이 친구요청을 수락하였습니다.','2024-11-18 17:39:07.551217',NULL,_binary '\0',_binary '','FRIEND_ACCEPT',42,43),(274,NULL,'미지아빠이 모임에 참가하셨습니다.','2024-11-18 17:57:10.926607',NULL,_binary '\0',_binary '','MEETING_JOIN',42,41),(275,NULL,'감자누나이 모임에 참가하셨습니다.','2024-11-18 17:57:16.139469',NULL,_binary '\0',_binary '','MEETING_JOIN',42,40),(276,NULL,'감자누나이 모임에 참가하셨습니다.','2024-11-18 17:57:16.260314',NULL,_binary '',_binary '\0','MEETING_JOIN',41,40),(277,NULL,'woong이 모임에 참가하셨습니다.','2024-11-18 17:58:35.506057',NULL,_binary '\0',_binary '','MEETING_JOIN',42,43),(278,NULL,'woong이 모임에 참가하셨습니다.','2024-11-18 17:58:35.823391',NULL,_binary '\0',_binary '','MEETING_JOIN',41,43),(281,NULL,'낑깡이 모임에 참가하셨습니다.','2024-11-18 18:01:32.801274',NULL,_binary '\0',_binary '','MEETING_JOIN',39,44),(282,NULL,'감자누나이 모임에 참가하셨습니다.','2024-11-18 18:01:56.879983',NULL,_binary '\0',_binary '','MEETING_JOIN',42,40),(283,NULL,'감자누나이 모임에 참가하셨습니다.','2024-11-18 18:01:57.153146',NULL,_binary '\0',_binary '','MEETING_JOIN',41,40),(284,NULL,'낑깡이 산책을 시작하셨습니다.','2024-11-18 22:29:28.692189',NULL,_binary '\0',_binary '','WALKING',42,44),(285,NULL,'낑깡이 산책을 시작하셨습니다.','2024-11-18 22:34:54.051669',NULL,_binary '\0',_binary '','WALKING',42,44),(286,NULL,'낑깡이 산책을 시작하셨습니다.','2024-11-18 22:36:58.157398',NULL,_binary '\0',_binary '','WALKING',42,44),(287,NULL,'미지아빠이 친구요청을 하였습니다.','2024-11-18 23:39:19.359596',41,_binary '\0',_binary '','FRIEND_INVITE',43,41),(288,NULL,'woong이 친구요청을 수락하였습니다.','2024-11-18 23:39:57.711661',NULL,_binary '\0',_binary '','FRIEND_ACCEPT',41,43),(289,NULL,'woong이 친구요청을 하였습니다.','2024-11-18 23:48:05.272059',43,_binary '',_binary '\0','FRIEND_INVITE',41,43),(290,NULL,'미지아빠이 친구요청을 수락하였습니다.','2024-11-18 23:54:14.022471',NULL,_binary '\0',_binary '','FRIEND_ACCEPT',43,41),(291,NULL,'미지아빠이 산책을 시작하셨습니다.','2024-11-19 00:08:35.549116',NULL,_binary '\0',_binary '','WALKING',39,41),(292,NULL,'미지아빠이 산책을 시작하셨습니다.','2024-11-19 00:08:35.812083',NULL,_binary '\0',_binary '','WALKING',43,41),(293,NULL,'미지아빠이 산책을 시작하셨습니다.','2024-11-19 00:16:30.932692',NULL,_binary '\0',_binary '','WALKING',39,41),(294,NULL,'미지아빠이 산책을 시작하셨습니다.','2024-11-19 00:16:31.239678',NULL,_binary '\0',_binary '','WALKING',43,41),(295,NULL,'미지아빠이 산책을 시작하셨습니다.','2024-11-19 00:17:04.630149',NULL,_binary '\0',_binary '','WALKING',39,41),(296,NULL,'초코쿠키이 친구요청을 하였습니다.','2024-11-19 00:52:45.980167',42,_binary '\0',_binary '','FRIEND_INVITE',41,42),(297,NULL,'미지아빠이 친구요청을 수락하였습니다.','2024-11-19 00:53:06.093202',NULL,_binary '\0',_binary '','FRIEND_ACCEPT',42,41),(298,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:10:34.132435',NULL,_binary '',_binary '','WALKING',44,42),(299,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:10:34.425115',NULL,_binary '',_binary '\0','WALKING',41,42),(300,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:10:41.084408',NULL,_binary '',_binary '','WALKING',44,42),(301,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:10:41.355663',NULL,_binary '',_binary '\0','WALKING',41,42),(302,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:10:49.794711',NULL,_binary '',_binary '','WALKING',44,42),(303,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:10:50.047514',NULL,_binary '',_binary '\0','WALKING',41,42),(304,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:11:15.471487',NULL,_binary '',_binary '','WALKING',44,42),(305,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:11:15.691888',NULL,_binary '',_binary '\0','WALKING',41,42),(306,NULL,'오이멍아빠이 산책을 시작하셨습니다.','2024-11-19 01:12:41.892250',NULL,_binary '',_binary '\0','WALKING',41,39),(307,NULL,'감자누나이 산책을 시작하셨습니다.','2024-11-19 01:12:48.479062',NULL,_binary '\0',_binary '','WALKING',39,40),(308,NULL,'오이멍아빠이 산책을 시작하셨습니다.','2024-11-19 01:13:06.547711',NULL,_binary '\0',_binary '','WALKING',41,39),(309,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:13:54.325525',NULL,_binary '',_binary '','WALKING',44,42),(310,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:13:54.611647',NULL,_binary '\0',_binary '','WALKING',41,42),(311,NULL,'오이멍아빠이 산책을 시작하셨습니다.','2024-11-19 01:14:55.581073',NULL,_binary '\0',_binary '','WALKING',41,39),(312,NULL,'낑깡이 산책을 시작하셨습니다.','2024-11-19 01:16:07.005709',NULL,_binary '\0',_binary '','WALKING',42,44),(313,NULL,'낑깡이 산책을 시작하셨습니다.','2024-11-19 01:17:50.264028',NULL,_binary '\0',_binary '','WALKING',42,44),(314,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:19:08.799055',NULL,_binary '',_binary '','WALKING',44,42),(315,NULL,'초코쿠키이 산책을 시작하셨습니다.','2024-11-19 01:19:09.061321',NULL,_binary '\0',_binary '','WALKING',41,42),(316,NULL,'낑깡이 산책을 시작하셨습니다.','2024-11-19 01:20:31.366678',NULL,_binary '\0',_binary '','WALKING',42,44),(317,NULL,'오이멍아빠이 산책을 시작하셨습니다.','2024-11-19 01:21:56.127597',NULL,_binary '\0',_binary '','WALKING',41,39),(318,NULL,'낑깡이 친구요청을 하였습니다.','2024-11-19 01:30:46.422909',44,_binary '',_binary '\0','FRIEND_INVITE',42,44),(319,NULL,'초코쿠키이 친구요청을 수락하였습니다.','2024-11-19 01:31:21.168188',NULL,_binary '\0',_binary '','FRIEND_ACCEPT',44,42),(320,NULL,'미지아빠이 친구요청을 하였습니다.','2024-11-19 09:05:07.510025',41,_binary '\0',_binary '\0','FRIEND_INVITE',39,41),(321,NULL,'오이멍아빠이 친구요청을 수락하였습니다.','2024-11-19 09:05:17.414629',NULL,_binary '\0',_binary '\0','FRIEND_ACCEPT',41,39),(322,NULL,'감자누나이 친구요청을 하였습니다.','2024-11-19 13:08:01.108578',40,_binary '',_binary '\0','FRIEND_INVITE',43,40),(323,NULL,'woong이 친구요청을 수락하였습니다.','2024-11-19 13:08:06.184914',NULL,_binary '\0',_binary '\0','FRIEND_ACCEPT',40,43);
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-19 13:43:19
