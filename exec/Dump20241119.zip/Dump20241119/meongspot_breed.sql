-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: k11d107.p.ssafy.io    Database: meongspot
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `breed`
--

DROP TABLE IF EXISTS `breed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `breed` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `breed`
--

LOCK TABLES `breed` WRITE;
/*!40000 ALTER TABLE `breed` DISABLE KEYS */;
INSERT INTO `breed` VALUES (1,'직접 입력'),(2,'골든 리트리버'),(3,'그레이트 데인'),(4,'그레이 하우스'),(5,'꼬동 드 툴레아'),(6,'노리치 테리어'),(7,'노퍽 테리어'),(8,'닥스훈트'),(9,'달마티안'),(10,'도베르만 핀셔'),(11,'동경이'),(12,'래브라도 리트리버'),(13,'로트와일러'),(14,'말티즈'),(15,'불테리어'),(16,'슈나우저'),(17,'셰퍼드'),(18,'핀셔'),(19,'베들링턴 테리어'),(20,'벨지안 그로넨달'),(21,'벨지안 말리노이즈'),(22,'보더콜리'),(23,'보르조이'),(24,'보스턴 테리어'),(25,'복서'),(26,'불도그'),(27,'비글'),(28,'비숑 프리제'),(29,'비즐라'),(30,'사모예드'),(31,'살루키'),(32,'삽살개'),(33,'셰틀랜드 시프도그'),(34,'스무스 폭스 테리어'),(35,'스코티시 테리어'),(36,'시바견'),(37,'시베리안 허스키'),(38,'시추'),(39,'아메리칸 아키타'),(40,'아메리칸 코커 스패니얼'),(41,'아펜핀셔'),(42,'아프간 하운드'),(43,'오스트레일리언 캐틀 도그'),(44,'오스트레일리언 켈피'),(45,'올드 잉글리시 쉽독'),(46,'와이어 폭스 테리어'),(47,'요크셔 테리어'),(48,'웨스트 하이랜드 화이트 테리어'),(49,'웰시 테리어'),(50,'이탈리안 그레이하운드'),(51,'잉글리시 스프링어 스패니얼'),(52,'잉글리시 포인터'),(53,'재퍼니스 스피츠'),(54,'잭 러셀 테리어'),(55,'저먼 셰퍼드'),(56,'저먼 쇼트헤어드 포인터'),(57,'저먼 와이어헤어드 포인터'),(58,'진돗개'),(59,'차우차우'),(60,'치와와'),(61,'카디건 웰시코기'),(62,'콜리'),(63,'파피용'),(64,'퍼그'),(65,'페키니즈'),(66,'펨브록 웰시코기'),(67,'포메라니안'),(68,'푸들'),(69,'프렌치 불도그'),(70,'프티 바세 그리퐁 방데');
/*!40000 ALTER TABLE `breed` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-19 13:43:20
