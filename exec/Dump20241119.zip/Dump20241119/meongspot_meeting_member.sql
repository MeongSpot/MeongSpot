-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: k11d107.p.ssafy.io    Database: meongspot
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `meeting_member`
--

DROP TABLE IF EXISTS `meeting_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_member` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `is_alarm` bit(1) NOT NULL,
  `join_at` datetime(6) NOT NULL,
  `dog_id` bigint DEFAULT NULL,
  `meeting_id` bigint DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK550jkbp561y6g4xvwi6hgj4sy` (`dog_id`),
  KEY `FK5o8slagsdk5g0ilj43m1fkm0d` (`meeting_id`),
  KEY `FKvkkq2bos055dev77230o8sf6` (`member_id`),
  CONSTRAINT `FK550jkbp561y6g4xvwi6hgj4sy` FOREIGN KEY (`dog_id`) REFERENCES `dog` (`id`),
  CONSTRAINT `FK5o8slagsdk5g0ilj43m1fkm0d` FOREIGN KEY (`meeting_id`) REFERENCES `meeting` (`id`),
  CONSTRAINT `FKvkkq2bos055dev77230o8sf6` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=331 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_member`
--

LOCK TABLES `meeting_member` WRITE;
/*!40000 ALTER TABLE `meeting_member` DISABLE KEYS */;
INSERT INTO `meeting_member` VALUES (286,_binary '','2024-11-18 14:38:34.833312',90,102,39),(287,_binary '','2024-11-18 14:40:15.881636',92,102,40),(288,_binary '','2024-11-18 14:43:28.671299',91,103,41),(289,_binary '','2024-11-18 14:44:52.936421',92,104,40),(290,_binary '','2024-11-18 14:45:45.475415',90,105,39),(291,_binary '','2024-11-18 14:46:42.856079',92,106,40),(293,_binary '','2024-11-18 14:49:40.319567',92,107,40),(295,_binary '','2024-11-18 14:57:35.918691',93,107,42),(296,_binary '','2024-11-18 15:00:29.059766',90,108,39),(298,_binary '','2024-11-18 15:01:46.674755',92,108,40),(301,_binary '','2024-11-18 17:36:10.064424',93,110,42),(302,_binary '','2024-11-18 17:37:03.522254',95,106,43),(303,_binary '','2024-11-18 17:37:16.474923',93,106,42),(304,_binary '','2024-11-18 17:37:16.477068',96,106,42),(306,_binary '','2024-11-18 17:49:25.288239',92,111,40),(307,_binary '','2024-11-18 17:49:56.533692',91,112,41),(308,_binary '','2024-11-18 17:50:00.565234',90,113,39),(309,_binary '','2024-11-18 17:53:59.541951',90,114,39),(325,_binary '','2024-11-19 09:09:30.853271',95,117,43),(326,_binary '','2024-11-19 09:10:03.033713',97,117,41),(327,_binary '','2024-11-19 09:10:58.762265',93,117,42),(328,_binary '','2024-11-19 11:52:56.552682',94,117,44),(329,_binary '','2024-11-19 13:06:28.783855',92,118,40),(330,_binary '','2024-11-19 13:07:27.861484',92,117,40);
/*!40000 ALTER TABLE `meeting_member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-19 13:43:22
